<?php

/**
 * Class Forminator_Addon_Zapier_Exception
 * Not Required but encouraged
 *
 * @since 1.0 Zapier Addon
 */
class Forminator_Addon_Zapier_Exception extends Exception {

}
