<?php

/**
 * Class Forminator_Addon_Activecampaign_Exception
 * Not Required but encouraged
 *
 * @since 1.0 Activecampaign Addon
 */
class Forminator_Addon_Activecampaign_Exception extends Exception {

}
