<?php

/**
 * Class Forminator_Addon_Activecampaign_Wp_Api_Exception
 * Exception holder for Activecampaign wp api
 *
 * @since 1.0 Activecampaign Addon
 */
class Forminator_Addon_Activecampaign_Wp_Api_Exception extends Forminator_Addon_Activecampaign_Exception {
}
