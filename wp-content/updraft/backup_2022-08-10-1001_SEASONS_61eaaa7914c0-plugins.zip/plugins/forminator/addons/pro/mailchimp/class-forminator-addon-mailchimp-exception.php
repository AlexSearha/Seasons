<?php

/**
 * Class Forminator_Addon_Mailchimp_Exception
 * Wrapper of Mailchimp Exception
 *
 * @since 1.0 Mailchimp Addon
 */
class Forminator_Addon_Mailchimp_Exception extends Exception {
}
